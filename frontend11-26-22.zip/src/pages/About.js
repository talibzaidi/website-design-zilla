import React from "react";
import {useNavigate} from 'react-router-dom';
import Home2 from "../components/Home2.js";
import Mobile7 from '../images/mobile7.png'
import Mobile8 from '../images/mobile8.png'
import software from '../images/Enterprisesoftware1.jpg'
import Mobile9 from '../images/mobile9.jpg'
import Mobile10 from '../images/mobile10.jpg'
import Colab from '../components/Collaborate'
import Learnmore from '../components/Learnmore'

function About(){
const navigate = useNavigate();
const data = [
  {
    text: 'Our Work',
    link: '/work'
  }
]
return(
<div>
    <section className="aboutus">
      <div className="container">
        <div className="mb70">
        <p  className="large">ABOUT US</p>
        <h1 style={{color:'black'}} className='mb30'>Hey, we're GoHaych.</h1>
        <p className="mb100 large">
        We are a London-based digital product and design studio.
        </p>
        <div className="mb70">
        <div className="row">
          <div className="col-md-6">
            <h2>Consumer's preferred digital products</h2>
            <p className="mb70 large">
            We create engaging digital solutions used by millions of people by applying behavioural research to customer experience.
            </p>
            <img src={Mobile7} alt='Mobile7' className='mb30 aboutussec1'/>
          </div>
          <div className="col-md-6">
            <div className="centeraligned">
              <img src={Mobile8} alt='Mobile7' className='mb30 aboutussec1' style={{width:'583' , height:'565'}}/>
            </div>
          </div>
        </div>
        </div>

        <div className="mb70">
        <div className="row">
          <div className="col-md-6">
            <div className="centeraligned">
              <img src={software} alt='Mobile7' className='mb30 aboutussec1' style={{width:'583' , height:'565'}}/>
            </div>
          </div>
          <div className="col-md-6">
            <h2>Industrial software that are increadble</h2>
            <p className="mb70 large">
            We design corporate software that is consumer centered and has the smooth, dynamic feel of the greatest consumer app
            </p>
            <img src={Mobile9} alt='Mobile7' className='mb30 aboutussec1'/>
          </div>
        </div>
        </div>
        <div className="mb70">
        <div className="row">
          <div className="col-md-6">
            <h2>Websites that tell the narrative of your company</h2>
            <p className="mb70 large">
            We collaborate with marketing departments of huge corporations and startups to create award-winning websites.
            </p>
            <img src={Mobile7} alt='Mobile7' className='mb30 aboutussec1'/>
          </div>
          <div className="col-md-6">
            <div className="centeraligned">
              <img src={Mobile10} alt='Mobile7' className='mb30 aboutussec1' style={{width:'583' , height:'565'}}/>
            </div>
          </div>
        </div>
        </div>

        </div>
      </div>
    </section>
    <div className="mb70"><Home2/></div>
    <div className="mb70"><Colab/></div>
    <div className="mb70"><Learnmore/></div>    

    

</div>
);}
export default About;