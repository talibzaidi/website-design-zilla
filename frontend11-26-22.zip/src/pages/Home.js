import React from "react";
import {useNavigate} from 'react-router-dom';
import SliderHome from '../components/SliderHome';
import Section2 from '../components/Section2.js';
import Blogs from '../components/Blogs.js'
import Testimonials from "../components/Testimonials.js";
import Colab from "../components/Collaborate.js"
import Learnmore from '../components/Learnmore.js'
import Faq from '../components/Faq'



function Home(){
const navigate = useNavigate();

function f1(){
var fadeTarget = document.getElementById("c1");
var fadeEffect = setInterval(function(){
    if (!fadeTarget.style.opacity){
        fadeTarget.style.opacity = 1;
    }
    if (fadeTarget.style.opacity > 0) {
        fadeTarget.style.opacity -= 0.3;
    } else {
        clearInterval(fadeEffect);
        fadeTarget.style.display = 'none';
    }
}, 200);
}

return(
<div>
  
<section className="home1">
<div className="container">
<div className="row">
<div className="col-md-12">
<div className="home1heading" >
    <p className="white aligncenter">We Create</p>
<h1 className=" mb15 white">Incredible Digital Products.</h1>
<p style={{color:'white', width:'70%' , marginLeft: '14%'}} className="mb40 large">We serve businesses, start-ups, and organizations to engender fresh initiatives. and create customer-friendly branding, websites, tools, and apps.</p>
<button className="btn7 rounded " onClick={() => navigate('contact')}><span className="text-green">Get a Quote</span></button>
</div>

<div className='home1socialicon'>
<ul>
    {/* <li>FOLLOW US</li>
    <li></li> */}
    <li><a href="https://twitter.com/dotoxygen" rel="noopener noreferrer" target="_blank"><i className="fa fa-twitter"></i></a></li>
    <li><a href="https://www.facebook.com/dotoxygen" rel="noopener noreferrer" target="_blank"><i className="fa fa-facebook"></i></a></li>
    <li><a href="https://www.linkedin.com/company/dotoxygen/" rel="noopener noreferrer" target="_blank"><i className="fa fa-linkedin"></i></a></li>
</ul>
</div>

</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
</section>

{/* < Home2 /> */}
< Section2 />



<SliderHome />
<Blogs/>
<Testimonials/>
{/* <SecBlog /> */}

<Faq/>

<Colab/>
<Learnmore/>
{/* <Project /> */}
{/* <Upnext data={data} /> */}

  {/*cookie popup*/}
  <div className="cookie1" id="c1">
    <p>By browsing this site you consent with our <span onClick={() => navigate('/cookies')}> cookie policy.</span><button onClick={() => f1()}>ACCEPT</button></p>
  </div>
  {/*END-cookie popup*/}

</div>
);}
export default Home;