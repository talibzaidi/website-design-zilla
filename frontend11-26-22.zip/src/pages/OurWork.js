import React from 'react'
import HandD from '../images/H&D.png'
import Colab from "../components/Collaborate.js"
import Learnmore from '../components/Learnmore.js'
import H20 from '../images/H2o.jpg'
import Pets from '../images/PETSIMAGE.jpg'
import Matcha from '../images/Matchaimage.png'
import {useNavigate} from 'react-router-dom';
    

export const OurWork = () => {

  const navigate = useNavigate();

const navigateblackh2o = () => {
    // 👇️ navigate to /home
    navigate('/blackh2o');
  };

  const navigateToHandD = () => {
    // 👇️ navigate to /contacts
    navigate('/handd');
  };
  const navigateToprettypetsgrooming = () => {
    // 👇️ navigate to /contacts
    navigate('/prettypetsgrooming');
  };
  const navigateTomacha = () => {
    // 👇️ navigate to /contacts
    navigate('/macha');
  };

  

  return (
    <div>
        <section className='ourwork'>
        <div className='container'>
        <div className='mb70'>
            <div className='row'>
            <p className='large'>OUR WORK WE <i className="fa fa-heart-o"></i></p>
                <h1 style={{color:'black' , width:'65%'}} className='mb70'>We’re rapidly growing. Our secret? We think differently.</h1>
                <div className='col-md-6'>
                 <img src={H20} alt='Development' className='mb30 casestudy'/>
                 <p>BLACK H2O</p>
         <h3 className='ourworkproject'>BLACK H2O</h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateblackh2o}>Case Study</button>
                </div>
                <div className='col-md-6'>
                 <img src={HandD} alt='Development' className='mb30 casestudy'  />
                 <p>H&D</p>
         <h3 className='ourworkproject'>H&D</h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateToHandD}>Case Study</button>
                </div>
                </div>
                </div>
                <div className='mb70'>
                <div className='row'>
                <div className='col-md-6'>
                 <img src={Pets} alt='Development' className='mb30 casestudy'/>
                 <p>PREETY PETS GROOMING</p>
         <h3 className='ourworkproject'>PREETY PETS GROOMING</h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateToprettypetsgrooming}>Case Study</button>
                </div>
                <div className='col-md-6'>
                 <img src={Matcha} alt='Development' className='mb30 casestudy'  />
                 <p>MACHA</p>
         <h3 className='ourworkproject'>MACHA</h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateTomacha}>Case Study</button>
                </div>
            </div>
            </div>
            
        </div>

        <Colab/>
<Learnmore/>
        </section>
    </div>
  )
};
 export default OurWork;
