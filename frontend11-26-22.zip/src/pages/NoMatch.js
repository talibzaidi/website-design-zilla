import React from "react";

function NoMatch(){
	return(
		<div className="col-md-12">
		<h3>Error 404: Page not found.</h3>
		</div>);
}
export default NoMatch;