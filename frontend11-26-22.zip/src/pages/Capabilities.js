import React from "react";
import Upnext from '../components/Upnext.js';
import triangle from '../images/Des.png';
import brackets from '../images/Dev.png';
import pen from '../images/Bra.png';

function Capabilities(){


return(
<div>
<section className="capabilities1">
<div className="container">
<div className="row">
<div className="col-md-6 order-md-2">
    <div className="frame"><img src={triangle} alt='triangle' /></div>
</div>{/*col*/}
<div className="col-md-6 order-md-1">
  <div className="b1">
    <h6 style={{color:'black'}}>SERVICES</h6>
    <h3>DESIGN</h3>
    <p>Design is not just the visual aspect of any product; it speaks for itself. It's a formal medium of communication to the users that explains the complete journey and answers all the strategic questions raised.</p>
    <p>The design of a product determines how the user will engage with it for the first time. We work hard to produce designs that leave a lasting impression. An impression that communicates with them. Creating a first-rate design for clients from the skills of professionals having vast experience.
We are aiming to amuse you and make you speechless while giving the options of either YES or NO.</p>
<div className="row">
    <div className="col-md-6">
      <ul>
          <li>UI/UX Design</li>
          <li>Web and mobile apps Design</li>
          <li>Motion Design</li>
      </ul>
    </div>
    <div className="col-md-6">
      <ul>
          <li>Graphic Design</li>
          <li>Visual content creation</li>
          <li>Advertising design</li>
      </ul>
    </div>
    </div>{/*row*/}
  </div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
</section>

<section className="capabilities1">
<div className="container">
<div className="row">
<div className="col-md-6">
    <div className="frame"><img src={brackets} alt='brackets' /></div>
</div>{/*col*/}
<div className="col-md-6">
  <div className="b1">
    <h3>Development</h3>
    <p>The digital product is more than simply a product; it is a dynamic visual evolution that tells the story of the identity. A product's development determines what it will do and where it will stand.
When you collaborate with a skilled and experienced developer, you can expect a predictable and pleasant result. We adopt a proactive approach and follow a tried-and-true procedure to ensure that your time and effort are utilised to their greatest potential at each level of growth.
When you work with us, you will receive a product that surpasses your expectations and is tailored to your specific requirements.</p>
    <p>We provide full-cycle development services that include demand-based scaling, business analysis, integrating the new product into your infrastructure, and designing the product from the ground up.</p>
  
    <div className="row">
    <div className="col-md-6">
      <ul>
      <li>Websites with 3D</li>
    <li>Complex animations</li>
    <li>eCommerce solutions</li>
      </ul>
    </div>
    <div className="col-md-6">
      <ul>
      <li>SaaS development</li>
    <li>Cross-platform & hybrid apps</li>
    <li>Mobile apps</li>
      </ul>
    </div>
    </div>{/*row*/}
  </div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
</section>

<section className="capabilities1">
<div className="container">
<div className="row">
<div className="col-md-6 order-md-2">
    <div className="frame"><img src={pen} alt='pen' /></div>
</div>{/*col*/}
<div className="col-md-6 order-md-1">
  <div className="b1">
    <h3>Branding</h3>
    <p>Branding is the process of creating a strong, memorable notion for an organisation and its products or services in the minds of the audience by incorporating elements such as design, mission statement, and a repeating theme throughout all marketing materials. Effective branding allows firms to differentiate themselves from the competition and build a loyal consumer base.</p>
    <p>A well-known brand may have a substantial impact on your bottom line by giving you a competitive advantage over your competitors and supporting you in obtaining and retaining clients. In a world where new firms (and hence new rivals) are cropping up daily, an established brand may be a valuable tool in attracting clients and developing a distinct look. We've shown ourselves throughout the years by being steady in this field and giving our clients the branding they need to distinguish their businesses!</p>
    <div className="row">
    <div className="col-md-6">
      <ul>
      <li>Brand Identity</li>
    <li>Brand Guidlines</li>
    <li>Logo Design</li>
      </ul>
    </div>
    <div className="col-md-6 mb70">
      <ul>
      <li>Iconography</li>
    <li>Illustration</li>
    <li>Animation</li>
      </ul>
    </div>
    </div>{/*row*/}
  </div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
</section>

</div>
);}
export default Capabilities;