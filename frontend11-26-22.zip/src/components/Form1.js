import React from "react";
import FormRegistration from '../components/forms/FormRegistration';
function Form1(){
	return (
		<div className="form">
			<FormRegistration />
		</div>
	);
}
export default Form1;