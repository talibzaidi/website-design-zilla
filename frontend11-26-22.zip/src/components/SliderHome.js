import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {useNavigate} from 'react-router-dom';
import b1 from '../images/b1.png'

function SliderHome(){
let settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
};

const navigate = useNavigate();

const navigateportfolio = () => {
    // 👇️ navigate to /home
    navigate('/portfolio');
  };


return(
  
<section className="slider_home">
  
<div className="container">
  <div className="slider1-001">
<div className="row">
  <div className="col-md-12">
  <p className="large float-start">OUR WORK WE <i className="fa fa-heart-o"></i></p>
  <button className="btn1 slidermargin">View all</button>
  </div>
</div>
</div>
    <Slider {...settings}>
    
    <div className="Slick-dots-edits">
      <div className="row">
        <div className="col-md-8 order-md-2">
          <img src={b1} alt="" className="slider-background"/>
        </div>
        
        <div className="col-md-4 order-md-1">
        <p>BLACK H2O</p>
         <h3 className="sliderhomeheading"><strong>Mother earth’s superfood</strong></h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateportfolio}>Case Study</button>
        </div>
         
         </div>
         </div>
      
         <div className="Slick-dots-edits">
      <div className="row">
        <div className="col-md-8 order-md-2">
          <img src={b1} alt="" className="slider-background"/>
        </div>
        
        <div className="col-md-4 order-md-1">
        <p>BLACK H2O</p>
         <h3 className="sliderhomeheading"><strong>Mother earth’s superfood</strong></h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateportfolio}>Case Study</button>
        </div>
         
         </div>
         </div>
         <div className="Slick-dots-edits">
      <div className="row">
        <div className="col-md-8 order-md-2">
          <img src={b1} alt="" className="slider-background"/>
        </div>
        
        <div className="col-md-4 order-md-1">
        <p>BLACK H2O</p>
         <h3 className="sliderhomeheading"><strong>Mother earth’s superfood</strong></h3>
         <p>Branding, Website Design, User Interface, User Experience</p>
         <button className="btn1" onClick={navigateportfolio}>Case Study</button>
        </div>
         
         </div>
         </div>
    </Slider>

</div>{/*con*/}
</section>
);}
export default SliderHome;