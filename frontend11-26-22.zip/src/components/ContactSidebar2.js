import React from "react";

function ContactSidebar2(){
return (
  <div>
    <h4>Sales</h4>
    <a href="mailto:sales@gohaych.com" rel="noopener noreferrer" target="_blank">sales@gohaych.com</a>
    <h4>Marketing</h4>
    <a href="mailto:hey@gohaych.com" rel="noopener noreferrer" target="_blank">marketing@gohaych.com</a>
    <h4>Careers</h4>
    <a href="mailto:careers@gohaych.com" rel="noopener noreferrer" target="_blank">careers@gohaych.com</a>
  </div>
);
}
export default ContactSidebar2;