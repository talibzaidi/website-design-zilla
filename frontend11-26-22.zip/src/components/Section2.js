import React from 'react'
import design from '../images/Design.jpg'
import development from '../images/Development.jpg'
import branding from '../images/Branding.jpg'
function Section2() {

  return (
    <section className="Section2">
        <div className="container">
        <div className="row">
        <div className="col-md-12">
            <h2 className='mb30' >"Agency for Design, Development & Branding."</h2>
            <p className='mb70 w70'>Throughout the United Kingdom, we are a well-respected design and development agency.To improve the digital experiences of millions of consumers, we teamed up with some of the world's most well-known brands and cutting-edge businesses.</p>
            <p className='mb70 large w70'>WE BUILD</p>
            <div className='container aligncenter'>
                <div className='col-md-12'>
                        <div className='row'>

                        <div className='col-md-4' style={{marginTop: '-55px'}}>
                            <img src={development} alt='Development' className='mb30 '/>
                            <h3 className='section2texts'>Development</h3>
                            </div>
                                <div className='col-md-4'>
                                <img src={design} alt='design' className='mb30'/>
                                <h3 className='section2texts'>Design</h3>
                                </div>
                        
                           
                            <div className='col-md-4'>
                            <img src={branding} alt='Branding' className='mb30'/>
                            <h3 className='section2texts'>Branding</h3>
                            </div>
                            </div>
                        </div>
                 
                    </div>
                </div>
        </div>
        </div>
    </section>
  )
}

export default Section2;