import React from "react";
import building from '../images/building.jpg';

function Address(){
return(
<section className="contact2 mb70">
<div className="container">
<div className="row">
<div className="col-md-6">
<div className="">
<h6 style={{color:'black'}} className='mb15'>GOHAYCH</h6>
  <p>23, Gunners Passage,</p>
<p>Wobblington,</p>
<p>North Ottershire</p>
<p>WZ52 5RQ</p>
<p>United Kingdom</p>
{/* <p style={{fontWeight:'600'}}>+44 20 7234 3456</p> */}
</div>    
</div>{/*col*/}
<div className="col-md-6">
      <div className="frame"><img src={building} alt='building' className="float-end" /></div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
</section>
);
}
export default Address;