const marital_status = [
    {key:'none', value:'Select a status'},
    {key: "single", value: "Single"},
    {key: "married", value: "Married"},
    {key: "widower", value: "Widower"},
    {key: "widow", value: "Widow"},
];
export default marital_status;