const gender = [
    {key:'none', value:'Select a status'},
    {key: "male", value: "Male"},
    {key: "female", value: "Female"},
    {key: "other", value: "Other"},
];
export default gender;