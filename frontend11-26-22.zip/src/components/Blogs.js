import React from 'react'
import {useNavigate} from 'react-router-dom';


function Blogs() {

  const navigate = useNavigate();

  const navigateToarticle = () => {
    // 👇️ navigate to /contacts
    navigate('/article');
  };
  const navigateToarticle2 = () => {
      // 👇️ navigate to /contacts
      navigate('/article2');
    };
    const navigateToarticle3 = () => {
      // 👇️ navigate to /contacts
      navigate('/article3');
    };
    const navigateToarticle4 = () => {
      // 👇️ navigate to /contacts
      navigate('/article4');
    };
    const navigateToarticle5 = () => {
      // 👇️ navigate to /contacts
      navigate('/article5');
    };

  const navigateToblogs = () => {
    // 👇️ navigate to /contacts
    navigate('/blogs');
  };
  return(
  <section className="Section2">
  <div className="container">
  <div className='row'>
  <div className='col-md-4 no_pad'>
    <p className='float-start large' style={{width:'0px'}}>BLOG</p>
    <button className='btn1 float-end' onClick={navigateToblogs} >View all</button>
  </div>
  <div className='col-md-4 no_pad'>
    <div className='blogsstyle'>
      <p>26 MAY 2020</p>
      <h3 className='bloghome'>Custom Construction Software Price, Advantages Implementation.</h3>
      <p>Various unpredictable procedures are utilized in the development business...</p>
      <button className="btn1" onClick={navigateToarticle}>Read more</button>
    </div>
  </div>
  <div className='col-md-4 no_pad'>
    <div className='blogsstyle'>
      <p>26 MAY 2020</p>
      <h3 className='bloghome'>Dedicated Team Model. Everything You Need to Know.</h3>
      <p>Programming improvement commitment model determination is a convoluted...</p>
      <button className="btn1" onClick={navigateToarticle2}>Read more</button>
    </div>
  </div>
  <div className='col-md-4 no_pad'>
    <div className='blogsstyle'>
      <p>26 MAY 2020</p>
      <h3 className='bloghome'>E-commerce Website Redesign in 2022 Guide for Owners</h3>
      <p>Unfortunately, these business nightmares become reality for too many companies...</p>
      <button className="btn1" onClick={navigateToarticle3}>Read more</button>
    </div>
  </div>
  <div className='col-md-4 no_pad'>
    <div className='blogsstyle'>
      <p>26 MAY 2020</p>
      <h3 className='bloghome'>Fixed Cost vs. Time and Materials. What is the Difference</h3>
      <p>Which choice should the business pick: fixed costs versus time and materials?...</p>
      <button className="btn1" onClick={navigateToarticle4}>Read more</button>
    </div>
  </div>
  <div className='col-md-4 no_pad'>
    <div className='blogsstyle'>
      <p>26 MAY 2020</p>
      <h3 className='bloghome'>Why Quality Assurance is Important, and What are Its Benefits.</h3>
      <p>Testing a couple of lines of code is just a single part of value confirmation (QA)...</p>
      <button className="btn1" onClick={navigateToarticle5}>Read more</button>
    </div>
  </div>
</div>{/*row*/}
</div>{/*con*/}
</section>
)}
export default Blogs