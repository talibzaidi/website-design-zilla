import React, { useRef } from 'react';
import emailjs from '@emailjs/browser';
import {useNavigate} from 'react-router-dom';

const Emailjs1 = () => {
const form = useRef();
const navigate = useNavigate();

const sendEmail = (e) => {
e.preventDefault();

emailjs.sendForm('service_1hjspxb', 'template_wf05e7w', form.current, '7qSiVQdQjJ30Jb6RI')
    .then((result) => {
        /*console.log(result.text);
        console.log('Message sent successfully.');*/
        e.target.reset();
        navigate('/contactthanks');
    }, (error) => {
        /*console.log(error.text);*/
        navigate('/contactoops');
});
};

    return (
        <form ref={form} onSubmit={sendEmail}>
            <input type="text" name="to_name" className='hidden' value="Muhammad Ashraf Khan" />
            <div className='row'>
            <div className='col-md-6'>
                <div className="form-floating">
                    <input type="text" className="form-control" id="floatingInput" placeholder="name@example.com" name="from_name" />
                    <label for="floatingInput">Your name</label>
                </div>
            </div>
            <div className='col-md-6'>
                <div className="form-floating">
                    <input type="email" className="form-control" id="floatingInput2" name="from_email" placeholder='Your Email' />
                    <label for="floatingInput">Your email</label>
                </div>
            </div>
            <div className='col-md-12'>
                <div className="form-floating">
                    <textarea className="form-control" id="floatingInput3" name="message" placeholder='Tell us about your project' />
                    <label for="floatingInput">Message</label>
                </div>
                <button type="submit" value="Send" className='btn6'>Send</button>
            </div>
            </div>
        </form>
    );
};
export default Emailjs1;