import React from 'react'

export const Faq = () => {
  return (
    <section className="home5">
    <div className="container">
    <div className="row">
    <div className="col-md-12">
      <p className='large '>FAQS</p>
      <div className="accordion mb70" id="accordionExample">
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingOne">
          <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">What are your specialities in design services?</button>
        </h6>
        <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
          <div className="accordion-body"><p>We work on an assortment of UX/UI and website composition projects, from making new items to improving current versatile applications, sites, and business programming. Client research, item procedure, UI, client experience plan, convenience testing, prototyping, website composition, and improvement are only a couple of the services we propose to assist you with making an effective computerized item.</p>
<p>Our website composition clients are often similar firms who utilize us for UX/UI configuration projects, which checks out since who preferred depicts an item over individuals who fabricated it? We're a website composition firm that figures an extraordinary site ought to successfully switch guests over completely to clients while offering a charming web experience predictable with the brand. Higher change rates are related to the incredible UX/UI of a computerized item or site. That is the reason, not at all like other plan firms, we have UX/UI originators working close by designers on all undertakings.</p>
</div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingTwo">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">What distinguishes GoHaych’s development from other leading software development service providers?</button>
        </h6>
        <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
          <div className="accordion-body"><p>We utilize best practice strategies and improvement procedures as a base for the speedy advancement of state-of-the-art mechanical arrangements in an arranged and deliberate way.
GoHaych offers full-cycle programming advancement benefits that flawlessly adjust to your venture goals and business requests, from IT system exhortation and exhaustive innovation guides through the start to finish execution of adaptable arrangements.</p></div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingThree">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Do you offer branding services, or do I need to seek out a different branding firm?</button>
        </h6>
        <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
          <div className="accordion-body"><p>We coordinate innovative and item skills under one rooftop and on similar tasks, not at all like most conventional computerized arrangement suppliers and client experience architects. Envision a marking firm working together with an IT firm — that is us.
</p></div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingFour">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">How much does hiring you for a UX/UI design project cost?</button>
        </h6>
        <div id="collapseFour" className="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
          <div className="accordion-body"><p>The venture scope, course of events, expectations, and group arrangement all impact our evaluation. At the point when the degree isn't permanently established or the venture is liquid, we like to chip away at a time-and-materials premise, where you pay us for the time we spend on the task. Most of our UX/UI commitments, be that as it may, are fixed-cost agreements. In this situation, after advancing however much as could reasonably be expected about your venture, we'll give you a total proposition. All assessments depend on hourly rates and the assessed number of hours the undertaking will take.

For instance, an ordinary undertaking could require 10 weeks and cost $150k to $200k. We would fabricate a particular rate card for you in light of the group synthesis for time and materials commitment. We additionally give limited costs to qualified new companies. To get a statement, kindly send us an email.

</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingFive">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">Do you have any experience working with start-ups? </button>
        </h6>
        <div id="collapseFive" className="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>We collaborate with new businesses of all shapes and sizes constantly as programming arrangement suppliers in Pakistan. What could be more remunerating than helping trailblazers in rejuvenating novel thoughts? We flourish in a quick-moving work environment that tests our capacities and cycles. As far as we might be concerned, the apex of accomplishment is seeing our startup clients flourish and overcome the world.

for new businesses that we put stock in. To find out more, send an email to us.

</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingSix">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">Are you able to assist us with the redevelopment of our vintage enterprise/B2B software?</button>
        </h6>
        <div id="collapseSix" className="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
          <div className="accordion-body"><p>Indeed, we're up for the assignment. We're one of only a handful of exceptional client experience associations having some expertise in big business plans and heritage business programming computerized progress. Throughout the long term, we've refined our interaction by refreshing computerized stages for Fortune 100 associations, including ADP, Amazon, and Facebook. Each new corporate venture starts with a careful investigation and exploration stage to drench ourselves in the business and task subtleties.

Our services range from client examination and data engineering to plan, prototyping, and client testing, as well as full-stack improvement and incorporating frameworks.
Our organization functions as an independent substance, keeping away from the organization of a large company and habitually working together with development labs and in-house groups.
</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingSeven">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">What is the best way to acquire a proposal for my project? </button>
        </h6>
        <div id="collapseSeven" className="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionExample">
          <div className="accordion-body"><p>Kindly send us an email first with a compact clarification of your task or an RFI/RFP if you're looking for a product arrangement supplier. We typically answer in no less than 24 hours to set up an underlying call and to address any squeezing requests. We'll pose a couple of inquiries about the undertaking objectives, crowd, plan, and other significant variables during our underlying contact. We can sign an NDA if important, yet all client interchanges are treated as private. to assess objectives and task draws near.
We'll email you a proposition, and we can set up a gathering to go through it. A full portrayal of our venture system, project stages, exercises, expectations, plan group cosmetics, and pertinent contextual analyses will be remembered for GoHaych's proposition.
</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingEight">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">What if I am not satisfied with your service?</button>
        </h6>
        <div id="collapseEight" className="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>A client's degree of fulfilment with a decent, administration, or experience.
Client bliss is critical since it shows that your crowd supports your strategic approaches. As per research, phenomenal consumer loyalty increments client maintenance, lifetime worth, and brand notoriety.
Be that as it may, low consumer loyalty evaluations are likewise critical. They can feature client irritations and deal information upheld experiences on the most proficient method to upgrade your contribution regarding the two services and in general consumer loyalty.
GoHaych deals with this plan and objectives to fulfil each client.

</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingNine">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
          Do I have to be local to work with you?</button>
        </h6>
        <div id="collapseNine" className="accordion-collapse collapse" aria-labelledby="headingNine" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>No, we offer types of assistance all over the planet. We know about every one of the necessities for your business, whether you are in Karachi or elsewhere in the world, and we know how to make you chuckle with our top-notch computerized plan and tailor-made service. We help you no matter how you look at it, and a portion of the service we offer incorporates customized client experience, web composition and improvement, online business, versatile applications, marking, and computerized showcasing service.
</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingTen">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">How long does a website redesign take?</button>
        </h6>
        <div id="collapseTen" className="accordion-collapse collapse" aria-labelledby="headingTen" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>Contingent upon the intricacy of the task and the requests the site should fulfil, a site update might require 45 to 90 days or longer. A total update might appear to be a major undertaking since website architecture may sometimes give off an impression of being secretive craftsmanship. We start with a definite conversation to go through your necessities and furnish us with the underlying unrefined components on which to foster your arrangement. We will relegate schoolwork, given the conversation, and when we complete your undertaking, we might plan a gathering — or maybe two — to register. Regularly, this technique requires half a month. As per our accomplices at Blend B2B, an exhaustive exploration approach is fundamental to acquiring clients and fostering the company's character.
</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingEleven">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">Can you handle ongoing maintenance?</button>
        </h6>
        <div id="collapseEleven" className="accordion-collapse collapse" aria-labelledby="headingEleven" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>For any business, fostering another computerized item and acquainting it with the general population is an astonishing achievement. Your item's turn of events and send-off includes many advances, like the real plan and coding, permitting plans, promoting, and that's just the beginning. Any remaining item should, nonetheless, have the option to refresh with the times. GoHaych realizes it well and has active to make your item versatile to the prerequisites for the improvements, and remedial upkeep, safeguard, risk-based, and condition-based.

</p>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h6 className="accordion-header" id="headingTwelve">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">Do you offer to consult?</button>
        </h6>
        <div id="collapseTwelve" className="accordion-collapse collapse" aria-labelledby="headingTwelve" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>GoHaych is likewise an accomplished data innovation expert with a shown history of working in the data innovation and administration industry. Gifted in UX/UI plan, Software as a Service (SaaS), Project Coordination, and Branding. We have solid data innovation experts, with a Microsoft Certified Professional zeroed in on data innovation.

</p>
          </div>
        </div>
      </div>

      <div className="accordion-item">
        <h6 className="accordion-header" id="headingThirteen">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThirteen" aria-expanded="false" aria-controls="collapseThirteen">What sort of support do you offer?</button>
        </h6>
        <div id="collapseThirteen" className="accordion-collapse collapse" aria-labelledby="headingThirteen" data-bs-parent="#accordionExample">
          <div className="accordion-body">
            <p>We help drive, new companies, little and average size organizations, and ventures in creating imaginative ideas and encouraging sites, computerized items, applications, and marking.

A venture's conveyance doesn't stamp its decision. Requesting the board is important when it rises. In this way, after conveyance, our experience with you doesn't end; it keeps on.

You have the certainty expected to keep up with your task.
Whenever help from GoHaych without sitting tight days for a reaction.
Because of input, rebuilding highlights your ongoing contribution.


</p>
          </div>
        </div>
      </div>



      
      
    </div>
    
    </div>
    </div>{/*row*/}
    </div>{/*con*/}
    </section>
  )
};
export default Faq
