import React from 'react';
import Navbar2 from './Navbar2.js';

function Header1(){
return(
    <Navbar2 />
);
}
export default Header1;