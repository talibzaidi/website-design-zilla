import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import commas from '../images/commas.jpg';

function Testimonials() {
    let settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
      };
  return (
<section className="testimonials">
<div className="container">

    <Slider {...settings}>
      <div>
      <div className="container">
<div className="row">
<div className="col-md-12">
<div className="aligncenter">

          <img src={commas} alt='commas' style={{width:'163px' , height:'107px' , display:'inline'}} className='mb70' />
        <p className="large">A digital agency with branding capabilities is a dream come true, and GoHaych is the best answer.</p>
          <h3 className='bold'>Caryl Ivan</h3>
          <p>CMO Othaim</p>

</div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
      </div>
      <div>
      <div className="container">
<div className="row">
<div className="col-md-12">
<div className="aligncenter">

          <img src={commas} alt='commas' style={{width:'163px' , height:'107px' , display:'inline'}} className='mb70' />
        <p className="large"> We discovered GoHaych is the top design provider of its sort after looking for UX/UI design businesses, and they generated a fantastic design for our Fitness App.</p>
          <h3 className='bold'>Leon Darbi</h3>
          <p>Founder Fitness App</p>

</div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
      </div>
      <div>
      <div className="container">
<div className="row">
<div className="col-md-12">
<div className="aligncenter">

          <img src={commas} alt='commas' style={{width:'163px' , height:'107px' , display:'inline'}} className='mb70' />
        <p className="large">Gohaych is the ideal solution provider, having produced a top-notch website for our brand Gohayech that is SEO friendly.
        </p>
          <h3 className='bold'>Muhammad Ashraf Khan</h3>
          <p>CEO DotOxygen</p>

</div>
</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
      </div>
    </Slider>

</div>{/*con*/}
</section>
  )
}

export default Testimonials