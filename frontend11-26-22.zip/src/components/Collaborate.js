import React from 'react'
import {useNavigate} from 'react-router-dom';

function Collaborate() {

  const navigate = useNavigate();
  const navigatocontact = () => {
    // 👇️ navigate to /home
    navigate('/contact');
  };

  return (
    <div className='responsive'>
    <div className='container'>
        <div className='row'>
            <div className='colaborate aligncenter mb70' style={{padding:'80px'}}>
                <h2>Collaborate with us</h2>
                <p>Get in touch to discuss how we can help you access technology.</p>
                <button className='btn2' onClick={navigatocontact}>Get in Touch</button>
            </div>
        </div>
    </div>
    </div>
  )
}

export default Collaborate