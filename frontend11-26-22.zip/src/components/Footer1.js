import React, {useState, useEffect} from "react";
import {useNavigate} from 'react-router-dom';

function Footer1(){
  const [show, setShow] = useState('block');
    const navigate = useNavigate();


    useEffect(()=>{
      if(window.location.href.indexOf("/landingpage") > -1) {
          setShow('none');
      } else {
          setShow('block');
      }
  })


const navigateToprivacy = () => {
    // 👇️ navigate to /contacts
    navigate('/privacypolicy');
  };

return(
<footer style={{display:show}}>
<div className="container">
<div className="row">
<div className="col-md-6 careers">

    <ul>
        
        <li><span onClick={navigateToprivacy}>PrivacyPolicy</span></li>
        <li><span onClick={navigateToprivacy}>Site map</span></li>
        <li><span onClick={() => navigate('/careers')}>Careers</span></li>
        
    </ul>
    <p className="mb30" style={{width: '70%'}}>GoHaych - An agency to provide topnotch services, nearby with only a click.</p>

</div>{/*col*/}
<div className="col-md-6 footeraligned">
  <div className="contact1 mb40" style={{marginTop: '0px'}}>
        <a href="mailto:hey@gohaych.com" rel="noopener noreferrer" target="_blank">inquiries@gohaych.com</a>
        <br></br>
        {/* <a href="tel:+44 20 7234 3456" rel="noopener noreferrer" target="_blank" >+44 20 7234 3456</a> */}
        </div>
        
        <div className="row">
          <div className="col-md-6">
            <ul className="sm1">
              <li><a href="https://www.facebook.com/profile.php?id=100071835553448">Like us on Facebook</a></li>
              <br/>
              <li>Follow us on Twitter</li>
            </ul>
          
            </div>
          <div className="col-md-6">
          <ul className="sm2">
              <li>Follow us on Linkedin</li>
              <br/>
              <li><a href="https://www.instagram.com/gohaych/?igshid=YmMyMTA2M2Y%3D">Follow us on Instagram</a></li>
            </ul>
         </div>
        </div>
        
       
       

</div>{/*col*/}
</div>{/*row*/}
</div>{/*con*/}
</footer>
);}
export default Footer1;